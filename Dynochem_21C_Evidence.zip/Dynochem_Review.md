# AE630 Dynochem review — 9 November 2026

Both required cases were run in the Mixing Web App 2.1.1, using Vessel 1 (AE630), Batch Liquid Mixing and Heat Transfer. Screenshots and text captures are included in evidence/. Both original native .edsdat exports are included in native_files/. They contain JSON within the app’s native wrapper. Both were reopened successfully in Dynochem, and their selected inputs and results were checked against the corresponding cases. Keep the .edsdat extensions for use with File → Open.

## Confirmed inputs

| Input | Value |
|---|---|
| Agitation | 91 rpm |
| Process temperature | 21 °C |
| Jacket fluid | SYLTHERM XLT |
| Jacket inlet temperature | 15 °C |
| Jacket mass flow | 4 kg/s |
| Inside / outside fouling coefficients | 5000 / 5000 W/(m² K) |
| Solution density | 930.04 kg/m³ |
| Dynamic viscosity | 1.51 cP |
| Specific heat capacity | 1.89717 kJ/(kg K), entered; displayed rounded to 1.90 |
| Thermal conductivity | 0.15 W/(m K) |
| Solvent basis | 60% NMP / 40% ethanol by volume |
| Initial / feed solvent volumes | 400 / 100 L |
| Project Intermediate A initially | 100 mol = 22 kg |
| Active NaOEt feed | 105 mol, 1.05 equivalents |
| Selected feed duration | 240 min |

The starting page contained water and a custom material with default properties. Water was removed from the calculation and the supplied single-material solution approximation was entered. Existing vessel, impeller and jacket geometry were retained. The unrelated right-hand comparator (RV231) remains visible in full-page captures; ONLY Vessel 1 results are used here.

## Results at 21 °C

| Quantity | Initial fill | Final fill |
|---|---:|---:|
| Mass, kg | 394.016 | 494.1653 |
| Volume, L | 423.6549 | 531.3377 |
| Mixing time, s | 5.5 | 7.9 |
| Agitator power, W | 142.96 | 142.96 |
| Power per mass, W/kg | 0.363 | 0.289 |
| Power per volume, W/m³ (calculated from power/volume) | 337.4 | 269.1 |
| Reynolds number | 3.36 × 10⁵ | 3.36 × 10⁵ |
| Flow regime | Turbulent | Turbulent |
| Impeller | Submerged | Submerged |
| Tip speed, m/s | 2.86 | 2.86 |
| Bulk velocity, m/s | 0.22 | 0.19 |
| U, W/(m² K) | 209.73 | 209.73 |
| Heat-transfer area, m² | 2.36 | 2.81 |
| UA, W/K | 495.854 | 589.372 |
| Jacket duty, kW (negative means cooling) | −2.873 | −3.392 |
| Coolant outlet, °C | 15.41 | 15.48 |
| Net cooling rate, °C/min | −0.219 | −0.208 |
| App minimum feed time, min | 107.6 | 90.6 |

Both volumes fall within the stated 209–912 L range. The 600 mm retreat curve impeller has 150 mm clearance and is fully submerged above 149.98 L. The vessel is 69% baffled. No observation badge was shown for either selected case after correcting the inputs. Short predicted macromixing times support bulk blending; they do not prove feed-point micromixing or instantaneous reaction behavior.

## Feed-time basis and interpretation

The heat-balance fields use generic names: app reactant A is the added NaOEt (105 mol), while app reactant B is the initial project Intermediate A (100 mol). App B is NOT the project's desired Intermediate B. The stoichiometric coefficient is 1.

The positive exotherm entered is 183 kJ/mol = 51 + 132 kJ/mol, representing deprotonation followed by ring closure. The app displays a limiting bulk-reactant heat output of 18,300 kJ. Its reported feed times match 105 × 183,000 / [UA × (21 − 15) × 60], i.e. the time for the entire 105 mol feed at the limiting heat-removal rate, including the 1.05 feed-to-bulk ratio. This numerical reconstruction excludes agitation and feed sensible heat and uses inlet-temperature driving force.

The earlier numbers were reproduced directly in the app at 20 °C with the same properties and jacket inputs:

| Process temperature | Initial fill, min | Final fill, min |
|---|---:|---:|
| 20 °C | 129.2 | 108.7 |
| 21 °C | 107.6 | 90.6 |

UA remains unchanged between those runs because the solution properties are held constant and the jacket remains at 15 °C. The change in duty and feed time follows the larger temperature driving force.

As an independent supplementary screen, the feed mass difference is 100.1493 kg. A 25 °C feed entering a 21 °C reactor contributes approximately 760.0 kJ of sensible heat. Using the conservative 105 × 183 kJ reaction basis, the displayed jacket duty (which allows for coolant warming), and 142.96 W agitation gives approximate minimum times of 122.0 min initially and 102.5 min finally: t = (19,215,000 + 760,000) / [(absolute jacket duty in W − 142.96) × 60]. These remain below 240 min. This supplementary calculation is external to the app and excludes side-reaction heat and reagent accumulation.

Side-reaction ethanolysis (−86 kJ/mol) is excluded from these screens. It must be treated using the amount of side reaction predicted in the kinetic/energy model; every mole must not be assumed to undergo all three reactions. These are steady heat-removal screens and do not establish the outcome of cooling failure or the impurity specification. Those remain separate Python-model checks.

## Assumptions and sources

The solution properties and masses/volumes are the approximations supplied in the attached checklist, Pasted markdown(7).md. Their underlying literature sources were not available in that attachment and have not been independently verified in this review. They must be cited or justified in the final report; they should not be described as experimentally measured solution properties.

Team_06_Brief(1).pdf, CHEN30010 Team 6, v18, technical notes and kinetic table (page 4), was checked. It permits solvent-dominated properties for mixing/heat-transfer estimates and specifies the solvent volumes, 100 mol initial charge, and the three reaction enthalpies. The selected 21 °C, 91 rpm, 105 mol and 240 min operating proposal comes from the supplied checklist, rather than being mandated by the brief.

Equipment geometry, SYLTHERM XLT properties and correlations are taken from the selected app's equipment database. Some nonessential UI readouts were inconsistent (for example the volume selector showed a stale value despite correct calculated fill volume); the calculated fill table, results, and app report were used. Geometry was not changed to force those display fields to agree.

## Native-file verification completed

| File | Native contents checked | Reopened in app | Results reproduced |
|---|---|---|---|
| AE630_Initial_Fill_21C.edsdat | Yes | Yes | 423.65 L, 21 °C, 91 rpm, UA 495.854 W/K, minimum feed 107.6 min |
| AE630_Final_Fill_21C.edsdat | Yes | Yes | 531.34 L, 21 °C, 91 rpm, UA 589.372 W/K, minimum feed 90.6 min |

The native exports retain the solution properties, vessel geometry, jacket settings and heat-balance inputs. A separate feed-time export is unnecessary for retaining the inputs: both native cases contain the dosing-controlled heat balance. The app's successful import notification and recomputed outputs were checked after the user selected each file in the browser's native file picker.

The current browser case is FINAL fill at 21 °C. Open either file through Dynochem File → Open; there is no need to associate .edsdat with a desktop application. The right-hand comparator is included by the app but is not part of the selected AE630 calculations.

The calculation, screenshot, native-export and reload checks are complete for the supplied checklist settings. Underlying literature references for the supplied solution-property approximations still need to be cited or justified in the project report. The separate Python kinetic, impurity and cooling-failure studies were not changed or revalidated in this task.

## Evidence contents

- initial_mixing.jpg: initial-fill properties and expanded mixing results.
- initial_heat_transfer.jpg / .txt: initial-fill properties, jacket settings and heat-balance inputs/results.
- final_mixing.jpg / .txt: final-fill properties and expanded mixing results.
- final_heat_transfer.jpg / .txt: final-fill heat-transfer and dosing-controlled heat balance.
- geometry.jpg / .txt: unchanged AE630 geometry at initial fill.
- final_app_report.txt: native app report text for the final fill; mixing time is shown more precisely there as 7.88 s.
- result.jpg: focused final-fill app report screenshot.
- initial_reload_verified.txt: initial-case inputs and outputs after native import.
- final_reload_verified.jpg / .txt: final-case inputs, heat-transfer results and feed-time screen after native import.
- native_file_checks.json: extracted verification values and SHA-256 hashes for the unmodified original exports.

AI use: ChatGPT Work was used on 9 November 2026 to enter the supplied inputs, read app outputs, reproduce the 20 °C reference feed times, and assemble this evidence. The exact backend model version was not exposed. Numerical entries were checked against the displayed results and final app report; both native exports were checked and successfully reopened in the app. The user performed local save and file-selection steps because browser file access was restricted.
